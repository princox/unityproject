﻿using UnityEngine;
using System.Collections;
public enum PlayerState{
	Idle,
	Jump,
	Death
}
public class Player : MonoBehaviour {
		public PlayerState PS; //플레이어 상태 변수 ps
		public float Jump_Power=30f;
		public float MoveSpeed=0.1f;
		private Rigidbody2D ri;

		void Start () {
			ri = this.GetComponent<Rigidbody2D>();
		}
		void Jump(){
			PS = PlayerState.Jump;
		    int A = Random.Range (-5, 5);
			ri.velocity=new Vector2(ri.velocity.x+A,Jump_Power);
		}
		void OnCollisionEnter2D(Collision2D coll){ 
			Jump();
		}
	
}
