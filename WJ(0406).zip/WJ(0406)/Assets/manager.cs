﻿using UnityEngine;
using System.Collections;

public class manager : MonoBehaviour {
	public GUIText t_text;
	private bool ismousepressed;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//Vector2 t = Input.GetTouch(0).position;
		if(Input.GetMouseButtonDown(0)){
			ismousepressed=true;
			t_text.text=Input.mousePosition.ToString()+"Touch Start";
		}
		else if(Input.GetMouseButtonUp(0)){
			ismousepressed=false;
			t_text.text=Input.mousePosition.ToString()+"Touch End";
			
		}
		if(ismousepressed){
			t_text.text=Input.mousePosition.ToString()+"Dragged";
		}
		//t_text.text = Input.touchCount.ToString();
		/*if (Input.touches.Length <= 0) {
			t_text.text = Input.touchCount.ToString ();
		} else {
			for (int i=0; i<Input.touchCount; i++) {
			
				if (Input.GetTouch (i).phase == TouchPhase.Began) {
					t_text.text = Input.touchCount+"Touch Begin";
				}
				if (Input.GetTouch (i).phase == TouchPhase.Moved) {
					Vector2 t = Input.GetTouch(i).position;
					t_text.text = Input.touchCount+"Touch Moved"+t.ToString();
				}
				if (Input.GetTouch (i).phase == TouchPhase.Ended) {
					t_text.text = Input.touchCount+"Touch Ended";
		
				}
			}
		}*/
	
	}
}
