﻿using UnityEngine;
using System.Collections;

public enum PlayerState{
	Idle,
	Jump,
	Death
}
public class Player : MonoBehaviour {
		public PlayerState PS; //플레이어 상태 변수 ps
		public float Jump_Power=40f;
		public float MoveSpeed=0.1f;
		private Rigidbody2D ri;
		private GameObject leftedge;
		private GameObject[] ball;

		void Start () {
		ri = this.GetComponent<Rigidbody2D> ();
		ball = new GameObject[]{};
	//	ball = GameObject.FindGameObjectsWithTag ("ball");
		}
		void Update(){
		ball = GameObject.FindGameObjectsWithTag ("ball");
		}
		void UpJump(){
			PS = PlayerState.Jump;
		    int A = Random.Range (-5, 5);
			ri.velocity=new Vector2(ri.velocity.x+A,Jump_Power);
		}
		void LeftJump(){
		PS = PlayerState.Jump;
		int A = Random.Range (-5, 5);
		ri.velocity=new Vector2(ri.velocity.x-3,5);
	}
		void RightJump(){
		PS = PlayerState.Jump;
		int A = Random.Range (-5, 5);
		ri.velocity=new Vector2(ri.velocity.x+3,5);
	}
		void OnCollisionEnter2D(Collision2D coll){ 
		if (coll.gameObject.name == "LeftEdge") {
			RightJump ();
		}
		if (coll.gameObject.name == "RightEdge") {
			LeftJump ();
		}
		if (coll.gameObject.name == "ball(Clone)" || coll.gameObject.name == "terrain") {
			UpJump();

		}
	}
	void OnCollisionExit2D(Collision2D coll) {  
		for(int i=0; i<ball.Length; i++){
			DestroyObject(ball[i],1);			
}
}
}
