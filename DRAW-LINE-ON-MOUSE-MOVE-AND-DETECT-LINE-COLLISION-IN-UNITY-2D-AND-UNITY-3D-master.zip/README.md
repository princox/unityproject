DRAW-LINE-ON-MOUSE-MOVE-AND-DETECT-LINE-COLLISION-IN-UNITY-2D-AND-UNITY-3D
==========================================================================

The Main objective of this Code sample is to explain how to Draw Line on mouse move and detect line collision in Unity2d and unity3d.




You can find complete tutorial on how to use the code repo here : <a href="http://www.theappguruz.com/sample-code/draw-line-mouse-move-detect-line-collision-unity2d-unity3d/">DRAW LINE ON MOUSE MOVE AND DETECT LINE COLLISION IN UNITY2D AND UNITY3D</a>

This Tutorial has been presented by The App Guruz - One of the best <a href="http://www.theappguruz.com/game-development/">Mobile Game Development Company in India</a>
