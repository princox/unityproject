﻿using UnityEngine;
using System.Collections;

public class button_move : MonoBehaviour {
	public Rigidbody2D ri;
	public void OnMouseDown(){
		ri.velocity=new Vector2(ri.velocity.x,8);
	}
	void Start () {
		ri = ri.GetComponent<Rigidbody2D>();
	}
	void update(){
		OnMouseDown ();
	}
}

