﻿using UnityEngine;
using System.Collections;

public class Mouse : MonoBehaviour {

	// Use this for initialization
	void OnMouseDown(){
		Debug.Log ("The Mouse id down on " + this.name);
	}
	void OnMouseUp(){
		Debug.Log ("The Mouse id Up on " + this.name);
	}
}
