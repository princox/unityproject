﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class StrightLine : MonoBehaviour 
{
	private LineRenderer line; // Reference to LineRenderer
	private Vector3 mousePos;	
	private Vector3 startPos;	// Start position of line
	private Vector3 endPos;	// End position of line
	private List<Vector3> pointList;
	public GameObject ball;
	
	void Update () 
	{
		// On mouse down new line will be created 
		if(Input.GetMouseButtonDown(0))
		{
			if(line == null)
				createLine();
			//mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			//mousePos.z = 0;
			pointList.RemoveRange(0,pointList.Count);
			//line.SetVertexCount(0);

			startPos = mousePos;
		}
		else if(Input.GetMouseButtonUp(0))
		{
			if(line)
			{
				//mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
				//mousePos.z = 0;
				//line.SetVertexCount(0);

				endPos = mousePos;
				addColliderToLine();
				line = null;
			}
		}
		else if(Input.GetMouseButton(0))
		{
			mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			mousePos.z = 0;
			if(line)
			{
				pointList.Add (mousePos);
				line.SetVertexCount (pointList.Count);
				line.SetColors(Color.black, Color.black);
				line.SetPosition(pointList.Count - 1, (Vector3)pointList [pointList.Count - 1]);
				Instantiate(ball,mousePos,transform.rotation);

			}
		}
	}
	// Following method creates line runtime using Line Renderer component
	private void createLine()
	{
		line = new GameObject("Line").AddComponent<LineRenderer>();

		line.material =  new Material(Shader.Find("Diffuse"));
		pointList = new List<Vector3> ();


		//line.SetVertexCount(0);
		line.SetWidth(0.1f,0.2f);
		line.SetColors(Color.black, Color.black);
		//line.useWorldSpace = true;    
	}
	// Following method adds collider to created line
	private void addColliderToLine()
	{
		EdgeCollider2D col = new GameObject("Collider").AddComponent<EdgeCollider2D> ();
		col.transform.parent = line.transform; // Collider is added as child object of line
		//float lineLength = Vector3.Distance (startPos, endPos); // length of line
		//col.size = new Vector3 (lineLength, 0.1f, 1f); // size of collider is set where X is length of line, Y is width of line, Z will be set as per requirement
		//Vector3 midPoint = (startPos + endPos)/2;
		//col.transform.position = midPoint; // setting position of collider object
		// Following lines calculate the angle between startPos and endPos
		//float angle = (Mathf.Abs (startPos.y - endPos.y) / Mathf.Abs (startPos.x - endPos.x));
		if((startPos.y<endPos.y && startPos.x>endPos.x) || (endPos.y<startPos.y && endPos.x>startPos.x))
		{
			//angle*=-1;
		}
		//angle = Mathf.Rad2Deg * Mathf.Atan (angle);
		//col.transform.Rotate (0, 0, angle);
	}
}